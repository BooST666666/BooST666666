import sqlite3
import sys
# code by 格物楼一组4栋 104 老年活动中心
con = sqlite3.connect("D:\\作业\\date\\studentsDate.db")# 创建数据库连接对象，第一次执行，创建数据库
print("数据库连接成功")
print("\t\t 学生信息管理系统")
while True:
    print("*" * 30)
    print("     请选择功能：")
    print("              0.新建学生信息管理系统数据库")
    print("              1.录入学生信息")
    print("              2.打印学生信息")
    print("              3.删除学生信息")
    print("              4.修改学生信息")
    print("              5.统计学生总数")
    print("              6.导出数据")
    print("              7.退出程序")
    print("*" * 30)
    op = input("                请输入：")
    if op =='0': # 新建数据库
        con.execute('''CREATE TABLE StudentsDate
        (StudentNo  TEXT PRIMARY KEY NOT NULL,
        StudentName      TEXT       NOT NULL,
        StudentSex       TEXT       NOT NULL,
        StudentTel       TEXT       NOT NULL,
        StudentBirthday  TEXT       NOT NULL,
        StudentLiveNo    TEXT       NOT NULL);''')
        print("成功创建！！")

    elif op == '1': # 录入学生信息
        cursor = con.cursor()
        StudentNo = input("请输入学号：")
        StudentName = input("请输入姓名：")
        StudentSex = input("请输入性别：")
        StudentTel = input("请输入联系电话：")
        StudentBirthday = input("请输入出生年份：")
        StudentLiveNo = input("请输入该学生的宿舍号：")
        cursor.execute(
            "INSERT INTO StudentsDate(StudentNO,StudentName,StudentSex,StudentTel,StudentBirthday,StudentLiveNo) VALUES ((?),(?),(?),(?),(?),(?))", \
            (StudentNo, StudentName, StudentSex, StudentTel, StudentBirthday, StudentLiveNo))
        con.commit()
        cursor.close()
        print("添加成功")

    elif op =='2': # 查询学生信息
        op1 = input("请输入查找关键字，* 代表查找全部数据,输出为空就代表无数据")
        cursor = con.cursor()
        if (op1 == '*'):
            mylist = cursor.execute("SELECT * FROM StudentsDate")
        else:
            # 模糊查找
            mylist = cursor.execute(
                "SELECT StudentNo,StudentName,StudentSex,StudentTel,StudentBirthday,StudentLiveNo FROM StudentsDate where StudentNo like ? or StudentName like ? or StudentSex like ? or StudentTel like ? or StudentBirthday like ? or StudentLiveNo like ? ",
                (op1.strip(), ('%' + op1.strip() + '%'), ('%' + op1.strip() + '%'), ('%' + op1.strip() + '%'),
                 ('%' + op1.strip() + '%'), ('%' + op1.strip() + '%')))
            # 显示结果
        for row in mylist:
            print("学号：", row[0],end=' ')
            print("姓名：", row[1], end=' ')
            print("性别：", row[2], end=' ')
            print("电话：", row[3], end=' ')
            print("出生年份：", row[4], end=' ')
            print("宿舍号：", row[5], end=' ')
        print("查询结束")
        cursor.close()

    elif op == '3': # 删除学生信息
        intPut = input("请输入你要删除的学生的学号：")
        cursor = con.cursor()
        mylist = cursor.execute("SELECT StudentNo,StudentName,StudentSex,StudentTel,StudentBirthday,StudentLiveNo FROM StudentsDate where StudentNo = (?)",(intPut.strip(),))
        check = input("是否确定删除此条记录？？（Y/N）") # 询问
        if check =='Y' or check == 'y':
            cursor.execute("DELETE FROM StudentsDate WHERE StudentNo = ?",(intPut.strip(),))
            con.commit()

    elif op == '4': # 修改学生信息
        intPut = input("请输入你要修改的学生的学号：")
        cursor = con.cursor()
        mylist = cursor.execute("SELECT StudentNo,StudentName,StudentSex,StudentTel,StudentBirthday,StudentLiveNo FROM StudentsDate where StudentNo =(?)",(intPut.strip(),))
        for row in mylist:
            print("1.学号：", row[0], end=' ')
            print("2.姓名：", row[1], end=' ')
            print("3.性别：", row[2], end=' ')
            print("4.电话：", row[3], end=' ')
            print("5.出生年份：", row[4], end=' ')
            print("6.宿舍号：", row[5], end=' ')
            print("0.退出")
            while True:
                op2 = input("请输入对应的操作码：")

                if op2 == '0': # 学号
                    break;

                elif op2 == '1':
                    changeinfo = input("请输入修改后的值：")
                    cursor.execute("UPDATE StudentsDate set StudentNo = ? where StudentNo = ?",(changeinfo.strip(),intPut.strip(),))
                    con.commit() # 在py中增删改一定要以commit结尾
                    print("修改成功")
                    break

                elif op2 == '2': # 名字
                    changeinfo = input("请输入修改后的值：")
                    cursor.execute("UPDATE StudentsDate set StudentName = ? where StudentNo = ?",
                                   (changeinfo.strip(), intPut.strip(),))
                    con.commit()
                    print("修改成功")
                    break;

                elif op2 == '3': # 性别
                    changeinfo = input("请输入修改后的值：")
                    cursor.execute("UPDATE StudentsDate set StudentSex = ? where StudentNo = ?",
                                   (changeinfo.strip(), intPut.strip(),))
                    con.commit()
                    print("修改成功")
                    break

                elif op2 == '4': # 电话
                    changeinfo = input("请输入修改后的值：")
                    cursor.execute("UPDATE StudentsDate set StudentTel = ? where StudentNo = ?",
                                   (changeinfo.strip(), intPut.strip(),))
                    con.commit()
                    print("修改成功")
                    break

                elif op2 == '5': # 出生年份
                    changeinfo = input("请输入修改后的值：")
                    cursor.execute("UPDATE StudentsDate set StudentBirthday = ? where StudentNo = ?",
                                   (changeinfo.strip(), intPut.strip(),))
                    con.commit()
                    print("修改成功")
                    break

                elif op2 == '6': # 宿舍号
                    changeinfo = input("请输入修改后的值：")
                    cursor.execute("UPDATE StudentsDate set StudentLiveNo = ? where StudentNo = ?",
                                   (changeinfo.strip(), intPut.strip(),))
                    con.commit()
                    print("修改成功")
                    break

                else:
                    print("输入有误，重新输入")
                    continue
            con.commit()


    elif op =='5':
        cursor = con.cursor()
        Number = cursor.execute("SELECT count(*) FROM StudentsDate ")
        for row in Number:
            print("库中有{0}名学生的记录".format(row[0]))
        cursor.close()


    elif op == '6':
        cursor = con.cursor()
        mylist = cursor.execute("SELECT * FROM StudentsDate")
        dataFile = open("D:\\作业\\date\\studentsave.txt", "w")
        for row in mylist:
            dataFile.write(
                "学号：" + row[0] + "  姓名：" + row[1] + " 性别：" + row[2] + "  电话" + row[3] + "  出生日期：" +
                row[4] + "  宿舍号：" + row[5] + "\n")
        dataFile.close()
        print("成功导出，存放在D:\作业\date\studentsave.txt下")

    elif op == '7':
        print("成功退出程序")
        sys.exit()

    else:
        print("操作错误，404")
        sys.exit()
# code by 格物楼一组4栋 104 老年活动中心