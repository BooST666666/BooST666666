def caozuo1():
    list1 = []
    for a in range(len(students)):
        list1.append(students[a][0])
    studentName = input("请输入你要查询的学生名字：")
    if studentName not in list1:
        print("没有这个学生")
    else:# code by 格物楼一组4栋 104 老年活动中心
        for i in range(len(students)):
            if studentName == students[i][0]:
                print("名字为：",studentName, end=" ")
                print("成绩：（依次为数学，英语，语文，政治）",(students[i][1]))

def caozuo2():
    y = 1
    i = 0
    fenshu = []
    while (y):
        name = str(input("输入一个名字"))
        for a in range(0, len(students)):
            if name == students[a][0]:
                print("存在该学生")
                y = 1# code by 格物楼一组4栋 104 老年活动中心
                break
            else:
                y = 0
    while i < 4:
        fenshu1 = int(input("输入一个整数"))
        if (fenshu1 >= 0 and fenshu1 <= 100):
            fenshu.append(fenshu1)
            print("添加成功")
        else:
            print("输入成绩有误，请重新输入")
            fenshu1 = int(input("输入一个整数"))
            fenshu.append(fenshu1)
        i = i + 1
    tuple1 = (name, fenshu)
    students.append(tuple1)
    print("添加成功，名字：{0},成绩：{1}（依次为数学，英语，语文，政治）".format(tuple1[0],tuple1[1]))

def caozuo3():
    list1 = []
    for a in range(len(students)):
        list1.append(students[a][0])
    studentName = input("请输入你要查询的学生名字：")
    if studentName not in list1:
        print("没有这个学生")
    else:
        for i in range(len(students)):
            if studentName == students[i][0]:
                print("名字为：", studentName, end=" ")
                print("平均成绩为：", float(sum(students[i][1])/4))


if __name__=='__main__':
    print("*" * 30)
    op = int(input("欢迎进入学生信息管理系统，操作：1.查询，2.添加新成员，3.查平均分。。。。。您的操作是："))
    print("*" * 30)
    students = [("Jane", [60, 70, 70, 60]), ("xinrong", [70, 80, 70, 80]), ("Sima", [90, 80, 85, 90])]
    if (op == 1):
        caozuo1()
    elif (op == 2):
        caozuo2()
    elif (op == 3):
        caozuo3()
    else:
        print("输入有误，被迫退出")
# code by 格物楼一组4栋 104 老年活动中心