from tkinter import *
from tkinter.messagebox import *

from Operation import Operation
# code by 格物楼一组4栋 104 老年活动中心
class StudentUI:

    def __init__(self):
        # 数据库的用户名和密码，从self.entry_1和self.entry_2中获得
        self.user = None
        self.password = None
        #  建立列表用于清除函数的参数传送
        self.list_1 = []
        self.root = Tk()
        self.root.iconbitmap("D:\\作业\\picture\\1.ico")
        self.screen_width = self.root.winfo_screenwidth()  # 获得屏幕宽度
        self.screen_height = self.root.winfo_screenheight()  # 获得屏幕高度
        # 设置窗口大小
        self.root.geometry("200x140+%d+%d" % (self.screen_width / 4, self.screen_height / 7))
        # 容器,添加各种组件
        self.frame_1 = Frame(self.root)
        # # 以place的形式添加到root中
        self.frame_1.place(x=0, y=0)

    # 学生信息管理系统主界面
    def init_1(self):
        # 设置窗口标题
        self.root.title("欢迎来到学生信息管理系统")
        # 设置窗口大小
        self.root.geometry("800x600")
        # self.root.minsize(800, 600)
        # 添加菜单
        menuber = Menu(self.root)
        # tearoff=0是关闭第一行虚线
        menu_1 = Menu(menuber, tearoff=0)
        menuber.add_cascade(label="文件", menu=menu_1)
        menu_2 = Menu(menuber,  tearoff=0)
        menuber.add_cascade(label="功能", menu=menu_2)
        menu_3 = Menu(menuber,  tearoff=0)
        menuber.add_cascade(label="帮助", menu=menu_3)
        # 添加菜单项
        menu_1.add_cascade(label="保存", command=lambda: Operation.savestudent(Operation))

        menu_2.add_cascade(label="添加学生", command=self.addstudent)
        menu_2.add_cascade(label="删除学生", command=self.deletestudent)
        menu_2.add_cascade(label="修改学生", command=self.updatestudent)
        menu_2.add_cascade(label="查询学生", command=self.selectstudent)# code by 格物楼一组4栋 104 老年活动中心
        menu_2.add_cascade(label="输出学生", command=self.showallstudent)

        menu_3.add_cascade(label="关于", command=self.about)
        # 将菜单加入root
        self.root["menu"] = menuber
        # 进入事件循环
        self.root.mainloop()

    # 关于信息
    @staticmethod
    def about():
        showinfo(title="关于", message="Code by:\n@ 格物楼一组4栋104 老年活动中心\n")

    # 清除文本框内容
    def clearentry(self):
        for i in range(len(self.list_1)):
            self.list_1[i].delete(0, 'end')

    # 添加学生
    def addstudent(self):
        # 清空frame_1的组件,防止组件重叠
        for widget in self.frame_1.winfo_children():
            widget.destroy()
        # 清空list_1
        self.list_1.clear()
        # 在容器frame中添加学生的各种信息
        label_1 = Label(self.frame_1, text="学号:")
        label_2 = Label(self.frame_1, text="姓名:")
        label_3 = Label(self.frame_1, text="性别:")
        label_4 = Label(self.frame_1, text="电话:")
        label_5 = Label(self.frame_1, text="出生日期:")
        label_6 = Label(self.frame_1, text="宿舍号:")
        entry_1 = Entry(self.frame_1, bd=5)
        entry_2 = Entry(self.frame_1, bd=5)
        entry_3 = Entry(self.frame_1, bd=5)
        entry_4 = Entry(self.frame_1, bd=5)
        entry_5 = Entry(self.frame_1, bd=5)
        entry_6 = Entry(self.frame_1, bd=5)

        # 以网格布局的形式加入到frame中
        label_1.grid(row=0, column=0)
        entry_1.grid(row=0, column=1)
        label_2.grid(row=1, column=0)
        entry_2.grid(row=1, column=1)
        label_3.grid(row=2, column=0)
        entry_3.grid(row=2, column=1)
        label_4.grid(row=3, column=0)
        entry_4.grid(row=3, column=1)
        label_5.grid(row=4, column=0)
        entry_5.grid(row=4, column=1)# code by 格物楼一组4栋 104 老年活动中心
        label_6.grid(row=5, column=0)
        entry_6.grid(row=5, column=1)
        # 将文本框添加到列表中
        self.list_1.append(entry_1)
        self.list_1.append(entry_2)
        self.list_1.append(entry_3)
        self.list_1.append(entry_4)
        self.list_1.append(entry_5)
        self.list_1.append(entry_6)
        # 添加按钮
        # tkinter要求由按钮（或者其它的插件）触发的控制器函数不能含有参数
        # 若要给函数传递参数，需要在函数前添加lambda:(匿名函数)
        button_1 = Button(self.frame_1, text="提交",
                          command=lambda: Operation.addstudent(Operation, entry_1.get(), entry_2.get(),
                                                               entry_3.get(), entry_4.get(), entry_5.get(), entry_6.get()))
        button_2 = Button(self.frame_1, text="清除", command=lambda: self.clearentry())
        button_1.grid(row=6, column=0)
        button_2.grid(row=6, column=1)

    # 删除学生
    def deletestudent(self):
        # 清空frame_1的组件,防止组件重叠
        for widget in self.frame_1.winfo_children():
            widget.destroy()
        # 清空list_1
        self.list_1.clear()
        # 在容器frame中添加学生的各种信息
        label_1 = Label(self.frame_1, text="学号:")
        label_1.grid(row=0, column=0)
        entry_1 = Entry(self.frame_1, bd=5)
        entry_1.grid(row=0, column=1)
        # 将文本框加入list_1中
        self.list_1.append(entry_1)
        button_1 = Button(self.frame_1, text="提交",
                          command=lambda: Operation.deletestudnet(Operation, entry_1.get()))
        button_2 = Button(self.frame_1, text="清除",
                            command=lambda: self.clearentry())
        button_1.grid(row=1, column=0)
        button_2.grid(row=1, column=1)

    # 更新学生
    def updatestudent(self):# code by 格物楼一组4栋 104 老年活动中心
        # 清空frame_1的组件,防止组件重叠
        for widget in self.frame_1.winfo_children():
            widget.destroy()
        # 清空list_1
        self.list_1.clear()
        # 在容器frame中添加学生的各种信息
        label_1 = Label(self.frame_1, text="学号:")
        label_2 = Label(self.frame_1, text="姓名:")
        label_3 = Label(self.frame_1, text="性别:")
        label_4 = Label(self.frame_1, text="电话:")
        label_5 = Label(self.frame_1, text="出生日期:")
        label_6 = Label(self.frame_1, text="宿舍号:")
        entry_1 = Entry(self.frame_1, bd=5)
        entry_2 = Entry(self.frame_1, bd=5)
        entry_3 = Entry(self.frame_1, bd=5)
        entry_4 = Entry(self.frame_1, bd=5)
        entry_5 = Entry(self.frame_1, bd=5)
        entry_6 = Entry(self.frame_1, bd=5)
        # 将文本框添加到列表中
        self.list_1.append(entry_1)
        self.list_1.append(entry_2)
        self.list_1.append(entry_3)
        self.list_1.append(entry_4)# code by 格物楼一组4栋 104 老年活动中心
        self.list_1.append(entry_5)
        self.list_1.append(entry_6)
        # 添加按钮
        button_1 = Button(self.frame_1, text="修改",
                          command=lambda: Operation.changestudent(Operation, entry_1.get(), entry_2.get(), entry_3.get(),
                                                                  entry_4.get(), entry_5.get(), entry_6.get()))
        button_2 = Button(self.frame_1, text="清除",
                          command=lambda: self.clearentry())
        # 说明
        label_show = Label(self.frame_1, text="请输入要修改的信息:\n(不需修改的信息不用填写)")
        # 以网格布局的形式加入到frame中
        label_1.grid(row=0, column=0)
        entry_1.grid(row=0, column=1)
        label_show.grid(row=1, column=0)
        label_2.grid(row=2, column=0)
        entry_2.grid(row=2, column=1)
        label_3.grid(row=3, column=0)
        entry_3.grid(row=3, column=1)
        label_4.grid(row=4, column=0)
        entry_4.grid(row=4, column=1)
        label_5.grid(row=5, column=0)
        entry_5.grid(row=5, column=1)
        label_6.grid(row=6, column=0)
        entry_6.grid(row=6, column=1)# code by 格物楼一组4栋 104 老年活动中心
        button_1.grid(row=7, column=0)
        button_2.grid(row=7, column=1)

    # 查询学生
    def selectstudent(self):
        # 清空frame_1的组件,防止组件重叠
        for widget in self.frame_1.winfo_children():
            widget.destroy()
        # 清空list_1
        self.list_1.clear()
        # 在容器frame中添加学生的各种信息
        label_1 = Label(self.frame_1, text="学号:")
        label_2 = Label(self.frame_1, text="姓名:")
        label_3 = Label(self.frame_1, text="性别:")
        label_4 = Label(self.frame_1, text="电话:")
        label_5 = Label(self.frame_1, text="出生日期:")
        label_6 = Label(self.frame_1, text="宿舍号:")
        entry_1 = Entry(self.frame_1, bd=5)
        entry_2 = Entry(self.frame_1, bd=5)
        entry_3 = Entry(self.frame_1, bd=5)
        entry_4 = Entry(self.frame_1, bd=5)
        entry_5 = Entry(self.frame_1, bd=5)
        entry_6 = Entry(self.frame_1, bd=5)
        entry_7 = Entry(self.frame_1, bd=5)
        # 将文本框添加到列表中
        self.list_1.append(entry_1)
        self.list_1.append(entry_2)
        self.list_1.append(entry_3)
        self.list_1.append(entry_4)
        self.list_1.append(entry_5)
        self.list_1.append(entry_6)
        self.list_1.append(entry_7)
        # 添加按钮
        button_1 = Button(self.frame_1, text="查询",
                          command=lambda: Operation.selectstudent(Operation, entry_1.get(), entry_2, entry_3, entry_4, entry_5, entry_6))
        button_2 = Button(self.frame_1, text="清除",
                          command=lambda: self.clearentry())
        # 说明
        label_show = Label(self.frame_1, text="查询结果如下:")
        # 以网格布局的形式加入到frame中
        label_1.grid(row=0, column=0)
        entry_1.grid(row=0, column=1)# code by 格物楼一组4栋 104 老年活动中心
        button_1.grid(row=1, column=0)
        button_2.grid(row=1, column=1)
        label_show.grid(row=2, column=0)
        label_2.grid(row=3, column=0)
        entry_2.grid(row=3, column=1)
        label_3.grid(row=4, column=0)
        entry_3.grid(row=4, column=1)
        label_4.grid(row=5, column=0)
        entry_4.grid(row=5, column=1)
        label_5.grid(row=6, column=0)
        entry_5.grid(row=6, column=1)
        label_6.grid(row=7, column=0)
        entry_6.grid(row=7, column=1)

    # 输出全部学生
    def showallstudent(self):
        # 清空frame_1的组件,防止组件重叠
        for widget in self.frame_1.winfo_children():
            widget.destroy()
        # 滚动条初始化（scrollBar为垂直滚动条，scrollBarx为水平滚动条）
        scrollBar = Scrollbar(self.frame_1)
        scrollBarx = Scrollbar(self.frame_1, orient=HORIZONTAL)
        # 靠右，充满Y轴
        scrollBar.pack(side=RIGHT, fill=Y)
        # 靠下，充满X轴
        scrollBarx.pack(side=BOTTOM, fill=X)
        lb = Listbox(self.frame_1, width=111, height=32,)
        lb.pack()
        # 而当用户操纵滚动条的时候，自动调用 Treeview 组件的 yview()与xview() 方法
        # 即滚动条与页面内容的位置同步
        scrollBar.config(command=lb.yview)
        scrollBarx.config(command=lb.xview)
        # 调用数据库方法
        Operation.showstudent(Operation, lb)
# code by 格物楼一组4栋 104 老年活动中心