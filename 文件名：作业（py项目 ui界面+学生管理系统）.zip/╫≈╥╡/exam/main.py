from GUi import *


student = StudentUI()
student.init_1()
# code by 格物楼一组4栋 104 老年活动中心