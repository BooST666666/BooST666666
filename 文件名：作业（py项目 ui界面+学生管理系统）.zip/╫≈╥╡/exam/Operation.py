from tkinter import END
from tkinter.messagebox import showerror, showinfo
# code by 格物楼一组4栋 104 老年活动中心
class Operation:
        # 初始化
        # 存储全部学生
        allstudent = []

        # 添加学生
        def addstudent(self, StudentNo, StudentName, StudentSex, StudentTel,StudentBirthday,StudentLiveNo):
            # 暂时存储学生信息
            student = [StudentNo, StudentName, StudentSex, StudentTel, StudentBirthday, StudentLiveNo]
            # 加入学生(判断学号是否重复)
            x = 0
            # 判断学号是否为空
            if StudentNo == "":
                showerror(title="错误界面", message="学号不能为空！\n加入失败！！！")
                return# code by 格物楼一组4栋 104 老年活动中心
            # 刚开始录入学生时，学号不可能重复
            if len(self.allstudent) == 0:
                self.allstudent.append(student)
                showinfo(title="提示界面", message="加入成功！！！")
            # 判断重复
            else:
                while x < len(self.allstudent):
                    if self.allstudent[x][0] != StudentNo:
                        x += 1
                    else:
                        showerror(title="错误界面", message="查询的学号是重复的！！！\n请重新输入学号！！！")
                        break
                else:
                    self.allstudent.append(student)
                    showinfo(title="提示界面", message="加入成功！！！")

        def deletestudnet(self, StudentNo): # 删除学生
            x = 0
            while x < len(self.allstudent):
                if self.allstudent[x][0] == StudentNo:
                    del self.allstudent[x]
                    showinfo(title="提示界面", message="删除学生成功!!!")
                    break
                else:
                    x += 1
            else:
                showerror(title="错误界面", message="不存在该学号的学生！！！")

            # 查询学生
        def selectstudent(self, StudentNo, entry_2, entry_3, entry_4, entry_5, entry_6):
                # 清空文本框
                entry_2.delete(0, 'end')
                entry_3.delete(0, 'end')
                entry_4.delete(0, 'end')
                entry_5.delete(0, 'end')
                entry_6.delete(0, 'end')
                x = 0
                while x < len(self.allstudent):
                    if self.allstudent[x][0] == StudentNo:
                        # 将查询到的结果放在文本框中
                        entry_2.insert(0, self.allstudent[x][1])
                        entry_3.insert(0, self.allstudent[x][2])
                        entry_4.insert(0, self.allstudent[x][3])
                        entry_5.insert(0, self.allstudent[x][4])
                        entry_6.insert(0, self.allstudent[x][5])
                        break
                    else:
                        x += 1
                else:
                    showerror(title="错误界面", message="未查询到当前学生！！！")

            # 修改学生
        def changestudent(self, StudentNo, StudentName, StudentSex, StudentTel, StudentBirthday, StudentLiveNo):
                x = 0
                while x < len(self.allstudent):
                    if self.allstudent[x][0] == StudentNo:
                        # 如果姓名不为空
                        if StudentName != "":
                            self.allstudent[x][1] = StudentName
                        if StudentSex != "":
                            self.allstudent[x][2] = StudentSex# code by 格物楼一组4栋 104 老年活动中心
                        if StudentTel != "":
                            self.allstudent[x][3] = StudentTel
                        if  StudentBirthday != "":
                            self.allstudent[x][4] =  StudentBirthday
                        if  StudentLiveNo != "":
                            self.allstudent[x][5] =  StudentLiveNo
                        showinfo(title="提示界面", message="修改学生信息成功!!!")
                        return
                    else:
                        x += 1
                else:
                    showerror(title="错误界面", message="不存在当前学生！！！")

        def showstudent(self, lb): # 输出学生
                for i in range(len(self.allstudent)):
                    lb.insert(END, "学号：%s  姓名：%s  性别：%s  电话：%s  出生日期：%s  宿舍号：%s  " %
                              (self.allstudent[i][0], self.allstudent[i][1], self.allstudent[i][2],self.allstudent[i][3],
                               self.allstudent[i][4], self.allstudent[i][5]))

                # 另存学生信息
        def savestudent(self):
                    # 以追加的形式添加
                dataFile = open("D:\\作业\\date1\\student.txt", "w")
                for r in self.allstudent:
                    dataFile.write(
                        "学号：" + r[0] + "  姓名：" + r[1] + " 性别：" + r[2] + "  电话" + r[3] + "  出生日期：" +
                        r[4] + "  宿舍号：" + r[5] + "\n")
                showinfo(title="提示界面", message="保存学生信息成功！！！\n保存路径如下：\nD:\\作业\\date1\\student.txt")
# code by 格物楼一组4栋 104 老年活动中心